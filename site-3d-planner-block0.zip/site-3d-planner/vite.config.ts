import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      manifest: {
        name: 'HomeCraft3D',
        short_name: 'HomeCraft3D',
        description: '3D-планировщик участка: дом, сарай, гараж',
        theme_color: '#242321',
        background_color: '#242321',
        display: 'standalone',
        start_url: '/',
        icons: [
          { src: 'icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: 'icon-512.png', sizes: '512x512', type: 'image/png' }
        ]
      },
      workbox: {
        // Кэш service worker'а — только оболочка приложения (JS/CSS/шрифты).
        // Данные проекта (участок, постройки, объекты) живут в IndexedDB,
        // а не в этом кэше — см. src/db/schema.ts.
        runtimeCaching: [
          {
            urlPattern: /^https:\/\/fonts\.googleapis\.com\/.*/i,
            handler: 'CacheFirst',
            options: { cacheName: 'google-fonts-cache' }
          }
        ]
      }
    })
  ]
})
