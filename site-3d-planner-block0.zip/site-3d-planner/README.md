# Участок 3D — блок 0

Технический фундамент: React + Vite + TypeScript + React Three Fiber, аккаунты через Firebase Auth, офлайн-хранилище на Dexie (IndexedDB) с изоляцией по пользователю, синхронизация с Firebase, PWA.

## Запуск

```
npm install
cp .env.example .env   # вписать конфиг своего Firebase-проекта
npm run dev
```

## Деплой (подробно)

### Firebase

1. console.firebase.google.com → Add project → название (внутреннее, не обязано совпадать с именем сайта)
2. Google Analytics можно выключить — не нужен
3. На странице проекта → иконка «</>» (Web) в ряду платформ
4. Название приложения → галочку «Also set up Firebase Hosting» **не ставить** (хостинг через Netlify)
5. Register app → скопировать значения `firebaseConfig` в `.env`, построчно в соответствующие `VITE_FIREBASE_*`
6. Build → Authentication → Get started → Sign-in method → включить Email/Password и Google (для Google нужно выбрать email поддержки)
7. Build → Firestore Database → Create database → регион (например eur3) → production mode
8. Firestore → Rules → вставить содержимое `firestore.rules` → Publish

### Netlify

**Быстро посмотреть:** убедиться, что в `.env` реальные значения (они запекаются при сборке) → `npm install && npm run build` → перетащить папку `dist` на app.netlify.com.

**Для постоянной разработки:**
1. Создать репозиторий на GitHub (без README-инициализации)
2. `git init && git add . && git commit -m "Block 0" && git branch -M main && git remote add origin <ссылка> && git push -u origin main`
3. Netlify → Add new site → Import from Git → GitHub → выбрать репозиторий (настройки сборки — из `netlify.toml`)
4. Site settings → Environment variables → добавить все переменные из `.env`
5. Если добавлены после первого деплоя — Deploys → Trigger deploy

### После деплоя

- Firebase → Authentication → Settings → Authorized domains → добавить адрес сайта
- Netlify → Site settings → Change site name → задать желаемое имя вместо случайного
- Search Console (search.google.com/search-console) → добавить сайт → запросить индексацию — ускоряет появление в поиске с недель до дней

## Название

**HomeCraft3D** — выбранное имя. Кириллицу для домена сознательно не используем — хуже поддерживается почтой/браузерами и ассоциируется с фишингом.

## Что уже работает

- [x] React + Vite + TS + R3F + drei — рендерится тестовая сцена (сетка + бокс + orbit-камера)
- [x] Аккаунты: вход/регистрация по почте и паролю + вход через Google
- [x] У каждого пользователя своя локальная база (Dexie) и свои данные в Firestore (ownerId + правила доступа)
- [x] Индикатор офлайн/онлайн в шапке
- [x] Dexie-схема (`src/db/schema.ts`) — sites / buildings / objects / syncQueue, у всех есть ownerId
- [x] Очередь синхронизации (`src/sync/syncQueue.ts`)
- [x] PWA-конфиг (`vite-plugin-pwa`)
- [x] `netlify.toml`

## Почему не встроенный офлайн-кэш Firestore

По умолчанию он держит до 40 МБ и рассчитан на кратковременные обрывы связи, а не на часы работы без сети. Источник истины — Dexie, Firestore используется только как бэкенд синхронизации через собственную очередь.

## Про аккаунты

Вход обязателен. Заходить нужно один раз при наличии сети — дальше сессия и локальные данные остаются на устройстве, можно работать офлайн под тем же аккаунтом. У каждого — свои участки, чужих не видно ни локально, ни в Firestore: это гарантируют правила доступа (`firestore.rules`), а не только интерфейс.

## Дизайн

Токены в `src/index.css` совпадают с `interface-concept.html`: графит + бумажный текст + один акцент (амбер).

## Что нужно доделать руками

- Firebase-проект: включить Auth-провайдеры и Firestore, вписать ключи в `.env`
- Иконки приложения: `public/icon-192.png`, `public/icon-512.png`

## Дальше

Блок 1 (редактор участка), уже с учётом того, что участок принадлежит конкретному пользователю. Дальше удобнее продолжать в Claude Code — файлы и терминал держатся между сессиями.
